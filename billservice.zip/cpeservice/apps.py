from django.apps import AppConfig


class CpeserviceConfig(AppConfig):
    name = 'cpeservice'
